import logging
import asyncio
from datetime import date, datetime, timezone, timedelta
from typing import Dict, Any
import re
import json

# Imports de lógica de negócio e utilitários
from memory_utils import (
    add_emotional_memory,
    get_emotional_memories,
    get_sabotage_patterns,
)
from task_manager import parse_and_update_agenda_items, parse_and_update_project_items
from eixa_data import get_all_daily_tasks, save_daily_tasks_data, get_project_data, save_project_data, get_user_history, get_all_projects 

from vertex_utils import call_gemini_api
from vectorstore_utils import get_embedding, add_memory_to_vectorstore, get_relevant_memories

# Importações de firestore_utils para operar com o Firestore
from firestore_utils import get_user_profile_data, get_firestore_document_data, set_firestore_document, save_interaction
from google.cloud import firestore

from nudger import analyze_for_nudges
from user_behavior import track_repetition
from personal_checkpoint import get_latest_self_eval
from translation_utils import detect_language, translate_text

import os
import yaml
import pytz

from config import DEFAULT_MAX_OUTPUT_TOKENS, DEFAULT_TEMPERATURE, DEFAULT_TIMEZONE, USERS_COLLECTION, TOP_LEVEL_COLLECTIONS_MAP, GEMINI_VISION_MODEL, GEMINI_TEXT_MODEL 

# CORREÇÃO CRÍTICA AQUI: Importar parse_incoming_input
from input_parser import parse_incoming_input

from profile_settings_manager import parse_and_update_profile_settings, update_profile_from_inferred_data

logger = logging.getLogger(__name__)

_base_eixa_persona_template_text = None
_user_profile_template_content = None
_user_flags_template_content = None

def _load_yaml_config(filepath: str, default_value: dict = None, log_name: str = "config"):
    if default_value is None:
        default_value = {}
    try:
        current_dir = os.path.dirname(os.path.abspath(__file__))
        full_filepath = os.path.join(current_dir, filepath)
        with open(full_filepath, 'r', encoding='utf-8') as f:
            config_data = yaml.safe_load(f)
        logger.info(f"{log_name.capitalize()} loaded successfully from {full_filepath}.")
        return config_data if config_data is not None else default_value
    except FileNotFoundError:
        logger.warning(f"{filepath} not found. Running without a {log_name}.", exc_info=True)
        return default_value
    except yaml.YAMLError:
        logger.warning(f"Error loading {filepath}. Running without a {log_name}.", exc_info=True)
        return default_value

def _initialize_templates():
    global _base_eixa_persona_template_text, _user_profile_template_content, _user_flags_template_content
    if _base_eixa_persona_template_text is None:
        _prompt_config_data = _load_yaml_config('prompt_config.yaml', {}, "prompt config")
        _base_eixa_persona_template_text = _prompt_config_data.get('base_eixa_persona', '')

        _user_profile_template_full = _load_yaml_config('minimal_user_profile_template.yaml', {}, "minimal user profile template")
        _user_profile_template_content = _user_profile_template_full.get('user_profile', {})

        _user_flags_template_full = _load_yaml_config('user_flags.yaml', {}, "user flags template")
        _user_flags_template_content = _user_flags_template_full.get('behavior_flags', {})

async def _extract_crud_intent_with_llm(user_id: str, user_message: str, history: list, gemini_api_key: str, gemini_text_model: str) -> dict | None:
    system_instruction_for_crud_extraction = """
    Você é um assistente de extração de dados altamente preciso. Sua única função é analisar a última mensagem do usuário,
    considerando o histórico de conversas e o perfil do usuário, para identificar INTENÇÕES CLARAS de CRIAÇÃO, ATUALIZAÇÃO ou EXCLUSÃO de TAREFAS OU PROJETOS.

    NÃO converse. SEJA CONCISO. SUA RESPOSTA DEVE SER APENAS UM BLOCO JSON.

    Se uma intenção de tarefa ou projeto for detectada, retorne um JSON com a seguinte estrutura:
    ```json
    {
      "intent_detected": "task" | "project",
      "action": "create" | "update" | "delete" | "complete",
      "item_details": {
        "id": "ID_DO_ITEM_SE_FOR_UPDATE_OU_DELETE",
        "name": "Nome do projeto ou descrição da tarefa",
        "description": "Descrição detalhada (se projeto) ou descrição da tarefa (se tarefa)",
        "date": "YYYY-MM-DD" | null,
        "status": "open" | "completed" | "in_progress" | null
      },
      "confirmation_message": "Você quer que eu adicione 'Comprar pão' para amanhã?"
    }
    ```
    Se a intenção **NÃO FOR CLARA** para um CRUD de tarefa/projeto, ou se a mensagem for ambígua, retorne SOMENTE:
    ```json
    {
      "intent_detected": "none"
    }
    ```
    Considere sinônimos e variações. Ex: "terminar", "finalizar", "concluir" para "complete" (status). "adicione", "crie", "nova" para "create". "mude", "altere" para "update". "remova", "exclua" para "delete".
    Para datas, sempre use o formato ISO (YYYY-MM-DD). "hoje" -> data atual. "amanhã" -> data atual + 1 dia. "próxima segunda" -> a data da próxima segunda-feira. Se nenhuma data for clara, use null.
    Sempre prefira extrair a descrição completa e a data/nome mais preciso.
    """

    llm_history = []
    for turn in history[-5:]:
        if turn.get("input"):
            llm_history.append({"role": "user", "parts": [{"text": turn.get("input")}]})
        if turn.get("output"):
            llm_history.append({"role": "model", "parts": [{"text": turn.get("output")}]})

    llm_history.append({"role": "user", "parts": [{"text": user_message}]})

    try:
        llm_response_raw = await call_gemini_api(
            api_key=gemini_api_key,
            model_name=gemini_text_model,
            conversation_history=llm_history,
            system_instruction=system_instruction_for_crud_extraction,
            max_output_tokens=1024, # Aumentar para evitar truncamento de JSON
            temperature=0.1
        )

        if llm_response_raw:
            json_match = re.search(r'```json\s*(\{.*?\})\s*```', llm_response_raw, re.DOTALL)
            if json_match:
                extracted_data = json.loads(json_match.group(1))
                logger.debug(f"ORCHESTRATOR | LLM extracted CRUD intent: {extracted_data}")
                return extracted_data
            else:
                logger.warning(f"ORCHESTRATOR | LLM did not return valid JSON for CRUD extraction. Raw response: {llm_response_raw[:200]}...", exc_info=True)
        return {"intent_detected": "none"}
    except Exception as e:
        logger.error(f"ORCHESTRATOR | Error during LLM CRUD intent extraction for user '{user_id}': {e}", exc_info=True)
        return {"intent_detected": "none"}


async def orchestrate_eixa_response(user_id: str, user_message: str = None, uploaded_file_data: Dict[str, Any] = None,
                                     view_request: str = None, gcp_project_id: str = None, region: str = None,
                                     gemini_api_key: str = None, gemini_text_model: str = GEMINI_TEXT_MODEL, # DEFAULT do config
                                     gemini_vision_model: str = GEMINI_VISION_MODEL, # DEFAULT do config
                                     firestore_collection_interactions: str = 'interactions',
                                     debug_mode: bool = False) -> Dict[str, Any]:
    _initialize_templates()

    debug_info_logs = []

    try:
        user_doc_in_eixa_users = await get_firestore_document_data('eixa_user_data', user_id)
        if not user_doc_in_eixa_users:
            logger.info(f"ORCHESTRATOR | Main user document '{user_id}' not found in '{USERS_COLLECTION}'. Creating it.")
            await set_firestore_document(
                'eixa_user_data',
                user_id,
                {"user_id": user_id, "created_at": datetime.now(timezone.utc).isoformat(), "last_active": datetime.now(timezone.utc).isoformat(), "status": "active"}
            )
            logger.info(f"ORCHESTRATOR | Main user document created for '{user_id}' in '{USERS_COLLECTION}'.")
        else:
            logger.debug(f"ORCHESTRATOR | Main user document '{user_id}' already exists in '{USERS_COLLECTION}'.")
    except Exception as e:
        logger.critical(f"ORCHESTRATOR | Failed to ensure main user document in '{USERS_COLLECTION}' for '{user_id}': {e}", exc_info=True)
        return {"status": "error", "response": f"Erro interno ao inicializar dados do usuário: {e}", "debug_info": debug_info_logs}

    user_profile = await get_user_profile_data(user_id, _user_profile_template_content)
    user_display_name = user_profile.get('name') if user_profile.get('name') else f"Usuário {user_id[:4]}..."
    logger.debug(f"ORCHESTRATOR | User profile loaded for '{user_id}'. Display name: '{user_display_name}'. Profile content keys: {list(user_profile.keys())}")

    eixa_state = user_profile.get('eixa_state', {})
    is_in_confirmation_state = eixa_state.get('awaiting_confirmation', False)
    confirmation_payload_cache = eixa_state.get('confirmation_payload_cache', {})
    stored_confirmation_message = eixa_state.get('confirmation_message', "Aguardando sua confirmação. Por favor, diga 'sim' ou 'não'.")

    # Correct definition and usage of user_flags_data
    user_flags_data_raw = await get_firestore_document_data('flags', user_id)
    user_flags_data = user_flags_data_raw.get("behavior_flags", {}) if user_flags_data_raw else {}

    if not user_flags_data:
        user_flags_data = _user_flags_template_content
        await set_firestore_document('flags', user_id, {"behavior_flags": user_flags_data})

    mode_debug_on = debug_mode or user_flags_data.get("debug_mode", False)
    if mode_debug_on:
        debug_info_logs.append("Debug Mode: ON.")

    response_payload = {
        "response": "", "suggested_tasks": [], "suggested_projects": [],
        "html_view_data": {}, "status": "success", "language": "pt", "debug_info": {}
    }

    # Usar os nomes de modelo do config.py (atualizado para gemini-1.5-flash se houver arquivo)
    gemini_final_model = gemini_vision_model if uploaded_file_data else gemini_text_model 


    await set_firestore_document(
        'eixa_user_data',
        user_id,
        {"last_active": datetime.now(timezone.utc).isoformat()},
        merge=True
    )

    if view_request:
        if view_request == "agenda":
            agenda_data = await get_all_daily_tasks(user_id)
            response_payload["html_view_data"]["agenda"] = agenda_data
            response_payload["response"] = "Aqui estão suas tarefas."
        elif view_request == "projetos":
            projects_data = await get_all_projects(user_id) # Usar get_all_projects
            response_payload["html_view_data"]["projetos"] = projects_data
            response_payload["response"] = "Aqui está a lista dos seus projetos."
        elif view_request == "diagnostico":
            diagnostic_data = await get_latest_self_eval(user_id)
            response_payload["html_view_data"]["diagnostico"] = diagnostic_data
            response_payload["response"] = "Aqui está seu último diagnóstico."
        elif view_request == "emotionalMemories":
            mems_data = await get_emotional_memories(user_id, 10)
            response_payload["html_view_data"]["emotional_memories"] = mems_data
            response_payload["response"] = "Aqui estão suas memórias emocionais recentes."
            logger.info(f"ORCHESTRATOR | Emotional memories requested and provided for user '{user_id}'.")
        elif view_request == "longTermMemory":
            response_payload["html_view_data"]["long_term_memory"] = user_profile
            response_payload["response"] = "Aqui está seu perfil de memória de longo prazo."
            logger.info(f"ORCHESTRATOR | Long-term memory (profile) requested and provided for user '{user_id}'.")
        else:
            response_payload["status"] = "error"
            response_payload["response"] = "View solicitada inválida."

        if mode_debug_on: response_payload["debug_info"]["orchestrator_debug_log"] = debug_info_logs
        return response_payload

    if not user_message and not uploaded_file_data:
        return {"status": "error", "response": "Nenhuma mensagem ou arquivo fornecido para interação."}

    user_input_for_saving = user_message or (uploaded_file_data.get('filename') if uploaded_file_data else "Ação do sistema")

    source_language = await detect_language(user_message or "Olá")
    response_payload["language"] = source_language
    logger.info(f"ORCHESTRATOR | Detected source language: '{source_language}' for user '{user_id}'.")

    user_message_for_processing = user_message
    if source_language != 'pt' and user_message:
        logger.info(f"ORCHESTRATOR | Translating user message from '{source_language}' to 'pt'. Original: '{user_message[:50]}...'.")
        translated_ai_response = await translate_text(user_message, "pt", source_language)
        if translated_ai_response is None:
            logger.error(f"ORCHESTRATOR | Failed to translate user message from '{source_language}' to 'pt' for user '{user_id}'. Original: '{user_message}'.", exc_info=True)
            return {"status": "error", "response": f"Ocorreu um problema ao traduzir sua mensagem de {source_language}.", "debug_info": debug_info_logs}
        user_message_for_processing = translated_ai_response
        logger.info(f"ORCHESTRATOR | User message after translation: '{user_message_for_processing[:50]}...'.")

    # Fetch full history before potential early exit due to confirmation logic
    full_history = await get_user_history(user_id, firestore_collection_interactions, limit=20)

    # --- Handle confirmation state FIRST ---
    if is_in_confirmation_state and confirmation_payload_cache:
        lower_message = user_message_for_processing.lower().strip()
        # Keywords for explicit confirmation. This check must be robust.
        if any(keyword in lower_message for keyword in ["sim", "ok", "confirmo", "confirma", "adicione", "crie", "pode", "certo", "beleza", "isso", "deletar", "excluir", "remover", "concluir", "finalizar", "ok, faça"]):
            # Add these keywords to catch user direct confirmation of CRUD from the LLM's own suggested action.
            # E.g., if LLM suggested "Você quer que eu delete X?" and user said "Deletar".
            # The intent_detected from previous turn is in confirmation_payload_cache.

            payload_to_execute = confirmation_payload_cache
            item_type = payload_to_execute.get('item_type')
            action = payload_to_execute.get('action')
            item_id = payload_to_execute.get('item_id')
            data = payload_to_execute.get('data', {})

            from crud_orchestrator import orchestrate_crud_action

            # Adicionar este log para inspecionar o payload exato antes da chamada ao CRUD
            logger.debug(f"ORCHESTRATOR | Calling orchestrate_crud_action with payload from confirmation cache: {{'user_id': '{user_id}', 'item_type': '{item_type}', 'action': '{action}', 'item_id': '{item_id}', 'data': {data}}}")

            crud_response = await orchestrate_crud_action(
                {"user_id": user_id, "item_type": item_type, "action": action, "item_id": item_id, "data": data}
            )

            if crud_response.get("status") == "success":
                final_ai_response = crud_response.get("message", "Ação concluída com sucesso.")
                response_payload["status"] = "success"
                logger.info(f"ORCHESTRATOR | User '{user_id}' confirmed action. CRUD executed successfully.")
            elif crud_response.get("status") == "duplicate":
                final_ai_response = crud_response.get("message", "Ação não realizada: item duplicado.")
                response_payload["status"] = "warning" # Status 'warning' para que o frontend possa exibir um toast específico
                logger.info(f"ORCHESTRATOR | User '{user_id}' confirmed action, but detected as duplicate.")
            else: # Covers "error" status from CRUD
                final_ai_response = crud_response.get("message", "Houve um erro ao executar a ação confirmada.")
                response_payload["status"] = "error"
                logger.error(f"ORCHESTRATOR | User '{user_id}' confirmed action, but CRUD failed: {crud_response}")

            # ALWAYS clear confirmation state after a 'yes' or 'no' response (even if CRUD failed/duplicate)
            try:
                # Modificação: Usar um dicionário vazio para resetar o estado.
                await set_firestore_document(
                    'profiles',
                    user_id,
                    {'user_profile.eixa_state': {}}, # Define como um dicionário vazio
                    merge=True # Continua a usar merge para não sobrescrever o user_profile inteiro
                )
                logger.info(f"ORCHESTRATOR | Confirmation state cleared for user '{user_id}'.")
            except Exception as e:
                logger.error(f"ORCHESTRATOR | Failed to clear confirmation state for user '{user_id}': {e}", exc_info=True)
                # Mesmo que a limpeza do estado falhe, a ação já foi executada/tentada.
                # A resposta final ainda pode ser enviada.

            response_payload["response"] = final_ai_response
            response_payload["debug_info"] = {
                "intent_detected": item_type, # Adicionar o intent_detected original
                "action_confirmed": action,
                "item_type_confirmed": item_type,
                "crud_result_status": crud_response.get("status"), # Passa o status do CRUD para o frontend
                "tarefas_ativas_injetadas": 0,
                "memoria_emocional_tags": [],
                "padroes_sabotagem_detectados": {},
            }
            await save_interaction(user_id, user_input_for_saving, response_payload["response"], source_language, firestore_collection_interactions)
            return response_payload # Exit early after handling confirmation

        # Keywords for explicit rejection
        elif any(keyword in lower_message for keyword in ["não", "nao", "cancela", "esquece", "pare", "não quero", "nao quero", "negativo"]):
            final_ai_response = "Ok, entendi. Ação cancelada."
            response_payload["status"] = "success" # Status success for cancellation
            try:
                # Modificação: Usar um dicionário vazio para resetar o estado.
                await set_firestore_document(
                    'profiles',
                    user_id,
                    {'user_profile.eixa_state': {}}, # Define como um dicionário vazio
                    merge=True
                )
                logger.info(f"ORCHESTRATOR | Confirmation state cleared for user '{user_id}'.")
            except Exception as e:
                logger.error(f"ORCHESTRATOR | Failed to clear confirmation state (rejection) for user '{user_id}': {e}", exc_info=True)

            response_payload["response"] = final_ai_response + " Como posso ajudar de outra forma?"
            response_payload["debug_info"] = {
                "intent_detected": "cancellation",
                "action_confirmed": "cancel",
                "item_type_confirmed": "none",
                "crud_result_status": "cancelled", # Indica cancelamento
            }
            await save_interaction(user_id, user_input_for_saving, response_payload["response"], source_language, firestore_collection_interactions)
            return response_payload # Exit early after handling rejection
        else:
            # User is in confirmation state but provided an ambiguous response. Re-prompt.
            response_payload["response"] = stored_confirmation_message # Use the stored message for re-prompt
            response_payload["status"] = "awaiting_confirmation"
            logger.info(f"ORCHESTRATOR | User '{user_id}' in confirmation state, but response was ambiguous. Re-prompting.")
            await save_interaction(user_id, user_input_for_saving, response_payload["response"], source_language, firestore_collection_interactions)
            return response_payload # Exit to await a clear response

    # --- If NOT in confirmation state (or if confirmation was just handled), proceed with normal flow ---
    input_parser_results = await asyncio.to_thread(parse_incoming_input, user_message_for_processing, uploaded_file_data)
    user_prompt_parts = input_parser_results['prompt_parts_for_gemini']
    gemini_model_override = input_parser_results['gemini_model_override']
    logger.info(f"ORCHESTRATOR | Input parser results for user '{user_id}' - Model override: {gemini_model_override}, Prompt parts count: {len(user_prompt_parts)}.")

    # Try to detect explicit profile setting changes first (these are direct, no confirmation needed)
    profile_settings_results = await parse_and_update_profile_settings(user_id, user_message_for_processing, _user_profile_template_content)
    if profile_settings_results.get("profile_updated"):
        direct_action_message = profile_settings_results['action_message']
        user_profile = await get_user_profile_data(user_id, _user_profile_template_content)
        intent_detected_in_orchestrator = "configuracao_perfil"
        response_payload["response"] = direct_action_message
        response_payload["status"] = "success"
        response_payload["debug_info"] = {"intent_detected": intent_detected_in_orchestrator, "crud_result_status": "success"} # Adicionar crud_result_status para frontend
        await save_interaction(user_id, user_input_for_saving, response_payload["response"], source_language, firestore_collection_interactions)
        return response_payload # Exit early if direct profile setting change occurred

    # Try to extract CRUD intent from LLM if no direct profile setting was changed
    crud_intent_data = await _extract_crud_intent_with_llm(user_id, user_message_for_processing, full_history, gemini_api_key, gemini_text_model)
    intent_detected_in_orchestrator = crud_intent_data.get("intent_detected", "conversa")

    if intent_detected_in_orchestrator in ["task", "project"]:
        item_type = crud_intent_data['intent_detected']
        action = crud_intent_data['action']
        item_details = crud_intent_data['item_details']
        llm_generated_confirmation_message = crud_intent_data['confirmation_message'] # Renomeado para clareza

        if item_type == 'task':
            task_description = item_details.get("name") or item_details.get("description")
            task_date = item_details.get("date") # This is the date string from LLM, e.g., "2024-07-25"

            if action == 'create' and (not task_description or not task_date):
                response_payload["response"] = "Não consegui extrair todos os detalhes necessários para a tarefa (descrição e data). Por favor, seja mais específico."
                response_payload["status"] = "error"
                await save_interaction(user_id, user_input_for_saving, response_payload["response"], source_language, firestore_collection_interactions)
                return response_payload

            # --- LÓGICA REFINADA PARA CORREÇÃO/VALIDAÇÃO DE ANO DO LLM ---
            corrected_task_date = task_date # Assume o que veio do LLM por padrão
            if task_date:
                try:
                    # Converte para objeto date sem timezone para manipulação de ano
                    parsed_date_from_llm = datetime.strptime(task_date, "%Y-%m-%d").date()
                    current_utc_date = datetime.now(timezone.utc).date()

                    # Passo 1: Se o LLM inferiu um ano que já passou em relação ao ano atual, force para o ano atual.
                    # Ex: LLM diz "2024-07-25" (em 2025). Mude para "2025-07-25".
                    if parsed_date_from_llm.year < current_utc_date.year:
                        parsed_date_from_llm = parsed_date_from_llm.replace(year=current_utc_date.year)
                        logger.info(f"ORCHESTRATOR | LLM inferred past year. Corrected task date from original {task_date} to current year: {parsed_date_from_llm.isoformat()}.")
                    
                    # Passo 2: Se, após o Passo 1, a data (mês/dia) ainda é no passado do ano atual, jogue para o próximo ano.
                    # Ex: LLM diz "2025-01-20" e hoje é "2025-07-16". Mude para "2026-01-20".
                    # Isso lida com casos como "próxima terça-feira" em Julho, se o LLM der um dia de Janeiro.
                    if parsed_date_from_llm < current_utc_date:
                        parsed_date_from_llm = parsed_date_from_llm.replace(year=current_utc_date.year + 1)
                        logger.info(f"ORCHESTRATOR | Corrected task date was still in the past. Adjusted to next year: {parsed_date_from_llm.isoformat()}.")
                    
                    corrected_task_date = parsed_date_from_llm.isoformat()
                    logger.info(f"ORCHESTRATOR | Final corrected task date (ISO) used for payload: {corrected_task_date}")

                except ValueError as ve:
                    logger.warning(f"ORCHESTRATOR | Task date '{task_date}' from LLM could not be parsed for year correction ({ve}). Using original from LLM as fallback.", exc_info=True)
                    # Fallback para usar a data como veio do LLM se houver erro de parseamento
            # --- FIM DA LÓGICA REFINADA DE CORREÇÃO/VALIDAÇÃO DE ANO DO LLM ---


            completed_status = True if action == 'complete' else (item_details.get('status') == 'completed' if 'status' in item_details else None)
            
            provisional_payload_data = {"description": task_description, "date": corrected_task_date} # Use corrected_task_date
            if completed_status is not None: provisional_payload_data["completed"] = completed_status
            
            provisional_payload = {
                "item_type": "task",
                "action": action if action != 'complete' else 'update',
                "item_id": item_details.get("id"),
                "data": provisional_payload_data
            }

            # --- MODIFICAÇÃO CHAVE: SEMPRE CONSTRUA A confirmation_message COM A DATA CORRIGIDA ---
            # Isso garante que a data na pergunta de confirmação esteja sempre correta
            if action == 'create':
                if corrected_task_date:
                    try:
                        local_tz = pytz.timezone(user_profile.get('timezone', DEFAULT_TIMEZONE))
                        # Garante que parsed_date_obj é timezone-aware ou cria a partir da string corrigida
                        parsed_date_for_display = local_tz.localize(datetime.fromisoformat(corrected_task_date))
                        formatted_date = parsed_date_for_display.strftime("%d de %B de %Y")
                        confirmation_message = f"Confirma que deseja adicionar a tarefa '{task_description}' para {formatted_date}?"
                    except ValueError as ve_display:
                        logger.warning(f"ORCHESTRATOR | Error formatting corrected_task_date '{corrected_task_date}' for display: {ve_display}. Using raw date.", exc_info=True)
                        confirmation_message = f"Confirma que deseja adicionar a tarefa '{task_description}' para a data especificada ({corrected_task_date})?"
                else: # Se corrected_task_date é None (não deveria acontecer se LLM extraiu data válida)
                     confirmation_message = f"Confirma que deseja adicionar a tarefa '{task_description}'?"
            elif action == 'complete': confirmation_message = f"Confirma que deseja marcar a tarefa '{task_description}' como concluída?"
            elif action == 'update': confirmation_message = f"Confirma que deseja atualizar a tarefa '{task_description}'?"
            elif action == 'delete': confirmation_message = f"Confirma que deseja excluir a tarefa '{task_description}'?"
            else: # Fallback para o caso de confirmation_message não ser definida acima
                confirmation_message = llm_generated_confirmation_message or "Confirma esta ação?"
            # --- FIM DA MODIFICAÇÃO CHAVE ---

        elif item_type == 'project':
            project_name = item_details.get("name")
            if action == 'create' and not project_name:
                response_payload["response"] = "Não consegui extrair o nome do projeto. Por favor, seja mais específico."
                response_payload["status"] = "error"
                await save_interaction(user_id, user_input_for_saving, response_payload["response"], source_language, firestore_collection_interactions)
                return response_payload

            provisional_payload = {
                "item_type": "project",
                "action": action,
                "item_id": item_details.get("id"),
                "data": item_details
            }
            if not llm_generated_confirmation_message: # Use the LLM-generated message for project or default
                if action == 'create': confirmation_message = f"Confirma que deseja criar o projeto '{project_name}'?"
                elif action == 'update': confirmation_message = f"Confirma que deseja atualizar o projeto '{project_name}'?"
                elif action == 'delete': confirmation_message = f"Confirma que deseja excluir o projeto '{project_name}'?"
                elif action == 'complete': confirmation_message = f"Confirma que deseja marcar o projeto '{project_name}' como concluído?"
                else: confirmation_message = "Confirma esta ação?"
            else:
                confirmation_message = llm_generated_confirmation_message


        # Save confirmation state and provisional payload to user profile
        await set_firestore_document(
            'profiles',
            user_id,
            {
                'user_profile.eixa_state': {
                    'awaiting_confirmation': True,
                    'confirmation_payload_cache': provisional_payload,
                    'confirmation_message': confirmation_message # Store message for re-prompt
                }
            },
            merge=True
        )
        logger.info(f"ORCHESTRATOR | LLM inferred {item_type} {action} intent for user '{user_id}'. Awaiting confirmation. Provisional payload: {provisional_payload}")

        response_payload["response"] = confirmation_message
        response_payload["status"] = "awaiting_confirmation"
        response_payload["debug_info"] = {
            "intent_detected": intent_detected_in_orchestrator,
            "action_awaiting_confirmation": action,
            "item_type_awaiting_confirmation": item_type,
            "provisional_payload": provisional_payload,
        }
        await save_interaction(user_id, user_input_for_saving, response_payload["response"], source_language, firestore_collection_interactions)
        return response_payload

    # --- Normal LLM conversation flow (if no CRUD intent detected) ---
    conversation_history = []
    # full_history is already fetched above
    for turn in full_history:
        if turn.get("input"):
            conversation_history.append({"role": "user", "parts": [{"text": turn.get("input")}]})
        if turn.get("output"):
            conversation_history.append({"role": "model", "parts": [{"text": turn.get("output")}]})

    debug_info_logs.append(f"History prepared with {len(full_history)} turns for LLM context.")
    logger.debug(f"ORCHESTRATOR | Conversation history sent to Gemini for user '{user_id}': {conversation_history[:2]}...")

    # --- INJETAR CONTEXTO TEMPORAL NO PROMPT DO LLM ---
    current_datetime_utc = datetime.now(timezone.utc)
    current_date_iso = current_datetime_utc.strftime("%Y-%m-%d")
    current_year = current_datetime_utc.year
    # Fornecer o nome do dia da semana em português para melhor interpretação do LLM
    day_names_pt = {0: "segunda-feira", 1: "terça-feira", 2: "quarta-feira", 3: "quinta-feira", 4: "sexta-feira", 5: "sábado", 6: "domingo"}
    current_day_of_week = day_names_pt[current_datetime_utc.weekday()]

    contexto_temporal = f"--- CONTEXTO TEMPORAL ATUAL ---\n"
    contexto_temporal += f"A data atual é {current_date_iso} ({current_day_of_week}). O ano atual é {current_year}.\n"
    contexto_temporal += f"Considere esta como a base para inferências de datas relativas (ex: 'amanhã', 'próxima semana', 'quarta-feira').\n"
    contexto_temporal += f"--- FIM DO CONTEXTO TEMPORAL ---\n\n"
    debug_info_logs.append("Temporal context generated for LLM.")

    # --- Memória Vetorial (Contextualização de Longo prazo) ---
    if user_message_for_processing and gcp_project_id and region:
        user_query_embedding = await get_embedding(user_message_for_processing, gcp_project_id, region)
        if user_query_embedding:
            relevant_memories = await get_relevant_memories(user_id, user_query_embedding, n_results=5) 
            if relevant_memories:
                context_string = "\n".join(["--- CONTEXTO DE MEMÓRIAS RELEVANTES DE LONGO PRAZO:"] + [f"- {mem['content']}" for mem in relevant_memories])
                logger.info(f"ORCHESTRATOR | Adding {len(relevant_memories)} relevant memories to LLM context for user '{user_id}'.")
                conversation_history.insert(0, {"role": "user", "parts": [{"text": context_string}]}) 
            else: # If user_query_embedding existed, but no relevant memories were found
                logger.debug(f"ORCHESTRATOR | No relevant memories found for user '{user_id}' based on embedding query.")
        else: # If get_embedding returns None, log and skip
            logger.warning(f"ORCHESTRATOR | Could not generate embedding for user message to retrieve memories for user '{user_id}'. Skipping vector memory retrieval.", exc_info=True)

    conversation_history.append({"role": "user", "parts": user_prompt_parts})

    # --- CONSTRUÇÃO DO CONTEXTO CRÍTICO ---
    contexto_critico = "--- TAREFAS PENDENTES E PROJETOS ATIVOS DO USUÁRIO ---\n"

    current_tasks = await get_all_daily_tasks(user_id)
    flat_current_tasks = [task_data for day_data in current_tasks.values() for task_data in day_data.get('tasks', [])]

    current_projects = await get_all_projects(user_id)

    if flat_current_tasks:
        contexto_critico += "Tarefas Pendentes:\n"
        for task in flat_current_tasks:
            desc = task.get('description', 'Tarefa sem descrição')
            status = task.get('completed', False)
            contexto_critico += f"- {desc} (Status: {'Concluída' if status else 'Pendente'})\n"
    else:
        contexto_critico += "Nenhuma tarefa pendente registrada.\n"

    if current_projects:
        contexto_critico += "Projetos Ativos:\n"
        for proj in current_projects:
            contexto_critico += f"- {proj.get('name', 'N/A')} (Status: {proj.get('progress_tags', 'N/A')})\n"
    else:
        contexto_critico += "Nenhum projeto ativo registrado.\n"
    contexto_critico += "--- FIM DO CONTEXTO CRÍTICO ---\n\n"
    debug_info_logs.append("Critical context generated for LLM.")

    # --- Construção do system_instruction dinâmico para o LLM (APRIMORADO) ---
    base_persona_with_name = _base_eixa_persona_template_text.replace("{{user_display_name}}", user_display_name)

    contexto_perfil_str = f"--- CONTEXTO DO PERFIL DO USUÁRIO ({user_display_name}):\n"
    profile_summary_parts = []

    if user_profile.get('psychological_profile'):
        psych = user_profile['psychological_profile']
        if psych.get('personality_traits'): profile_summary_parts.append(f"  - Traços de Personalidade: {', '.join(psych['personality_traits'])}")
        if psych.get('diagnoses_and_conditions'): profile_summary_parts.append(f"  - Condições/Diagnósticos: {', '.join(psych['diagnoses_and_conditions'])}")
        if psych.get('historical_behavioral_patterns'): profile_summary_parts.append(f"  - Padrões Comportamentais Históricos: {', '.join(psych['historical_behavioral_patterns'])}")
        if psych.get('coping_mechanisms'): profile_summary_parts.append(f"  - Mecanismos de Coping: {', '.join(psych['coping_mechanisms'])}")

    if user_profile.get('cognitive_style'):
        profile_summary_parts.append(f"  - Estilo Cognitivo: {', '.join(user_profile['cognitive_style'])}")

    if user_profile.get('communication_preferences'):
        comm_pref = user_profile['communication_preferences']
        profile_summary_parts.append(f"  - Preferências de Comunicação (Tom): {comm_pref.get('tone_preference', 'N/A')}")
        profile_summary_parts.append(f"  - Preferências de Comunicação (Estilo de Intervenção): {comm_pref.get('intervention_style', 'N/A')}")
        if comm_pref.get('specific_no_gos'): profile_summary_parts.append(f"  - Regras Específicas para EIXA (NÃO FAZER): {'; '.join(comm_pref['specific_no_gos'])}")

    if user_profile.get('current_projects'):
        project_names = [p.get('name', 'N/A') for p in user_profile['current_projects']]
        profile_summary_parts.append(f"  - Projetos Atuais: {', '.join(project_names)}")

    if user_profile.get('goals', {}).get('long_term'):
        goals_text = [g.get('value', 'N/A') for g in user_profile['goals']['long_term']]
        profile_summary_parts.append(f"  - Metas de Longo Prazo: {', '.join(goals_text)}")

    if user_profile.get('eixa_interaction_preferences', {}).get('expected_eixa_actions'):
        actions_text = user_profile['eixa_interaction_preferences']['expected_eixa_actions']
        profile_summary_parts.append(f"  - Ações Esperadas da EIXA: {', '.join(actions_text)}")

    if user_profile.get('daily_routine_elements', {}).get('alerts_and_reminders'):
        alerts_rem = user_profile['daily_routine_elements']['alerts_and_reminders']
        alerts_list = []
        if alerts_rem.get('hydration'): alerts_list.append(f"Hidratação: {alerts_rem['hydration']}")
        if alerts_rem.get('eye_strain'): alerts_list.append(f"Fadiga Visual: {alerts_rem['eye_strain']}")
        if alerts_rem.get('mobility'): alerts_list.append(f"Mobilidade: {alerts_rem['mobility']}")
        if alerts_list: profile_summary_parts.append(f"  - Alertas de Rotina: {'; '.join(alerts_list)}")

    contexto_perfil_str += "\n".join(profile_summary_parts) if profile_summary_parts else "  Nenhum dado de perfil detalhado disponível.\n"
    contexto_perfil_str += "--- FIM DO CONTEXTO DE PERFIL ---\n\n"

    # Concatena todos os contextos para a system_instruction final
    final_system_instruction = contexto_temporal + contexto_critico + contexto_perfil_str + base_persona_with_name

    logger.info(f"ORCHESTRATOR | Calling Gemini API with model '{gemini_final_model}' for user '{user_id}'.")
    gemini_response_text_in_pt = await call_gemini_api(
        api_key=gemini_api_key,
        model_name=gemini_final_model,
        conversation_history=conversation_history,
        system_instruction=final_system_instruction,
        max_output_tokens=DEFAULT_MAX_OUTPUT_TOKENS,
        temperature=DEFAULT_TEMPERATURE
    )
    logger.info(f"ORCHESTRATOR | Gemini API call completed for user '{user_id}'. Raw response received: {gemini_response_text_in_pt is not None}.")

    final_ai_response = gemini_response_text_in_pt

    if not final_ai_response:
        final_ai_response = "Não consegui processar sua solicitação no momento. Tente novamente."
        response_payload["status"] = "error"
        logger.error(f"ORCHESTRATOR | Gemini response was None or empty for user '{user_id}'. Setting response_payload status to 'error'.", exc_info=True)
    else:
        profile_update_json = None # Inicializa profile_update_json para evitar UnboundLocalError
        json_match = re.search(r'```json\s*(\{.*?\})\s*```', final_ai_response, re.DOTALL)
        if json_match:
            try:
                profile_update_json_str = json_match.group(1)
                profile_update_data = json.loads(profile_update_json_str)
                profile_update_json = profile_update_data.get('profile_update')

                final_ai_response = re.sub(r'```json.*?```', '', final_ai_response, flags=re.DOTALL).strip()
                logger.info(f"ORCHESTRATOR | Detected profile_update JSON from LLM for user '{user_id}'.")
            except json.JSONDecodeError as e:
                logger.warning(f"ORCHESTRATOR | Failed to parse profile_update JSON from LLM: {e}. Raw JSON: {json_match.group(1)[:100]}...", exc_info=True)
            except AttributeError as e:
                logger.warning(f"ORCHESTRATOR | Profile update JSON missing 'profile_update' key: {e}. Raw data: {profile_update_data}", exc_info=True)


        if source_language != "pt":
            logger.info(f"ORCHESTRATOR | Translating AI response from 'pt' to '{source_language}' for user '{user_id}'. Original: '{final_ai_response[:50]}...'.")
            translated_ai_response = await translate_text(final_ai_response, source_language, "pt")

            if translated_ai_response is None:
                logger.error(f"ORCHESTRATOR | Translation of AI response failed for user '{user_id}'. Original PT: '{final_ai_response}'. Target language: '{source_language}'.", exc_info=True)
                fallback_error_msg_pt = "Ocorreu um problema ao traduzir minha resposta. Por favor, tente novamente."
                translated_fallback = await translate_text(fallback_error_msg_pt, source_language, "pt")
                final_ai_response = translated_fallback if translated_fallback is not None else fallback_error_msg_pt
                response_payload["status"] = "error"
            else:
                final_ai_response = translated_ai_response
            logger.info(f"ORCHESTRATOR | AI response after translation: '{final_ai_response[:50]}...'.")
        else:
            logger.info(f"ORCHESTRATOR | No translation needed for AI response (source_language is 'pt') for user '{user_id}'.")

    response_payload["response"] = final_ai_response
    if response_payload["status"] == "success" and ("Não consegui processar sua solicitação" in final_ai_response or "Ocorreu um problema ao traduzir" in final_ai_response):
        response_payload["status"] = "error"
        logger.warning(f"ORCHESTRATOR | Response for user '{user_id}' contained a fallback error message, forcing status to 'error'.")


    await save_interaction(user_id, user_input_for_saving, response_payload["response"], source_language, firestore_collection_interactions)
    logger.info(f"ORCHESTRATOR | Interaction saved for user '{user_id}'. Final response status: {response_payload['status']}.")

    if profile_update_json:
        await update_profile_from_inferred_data(user_id, profile_update_json, _user_profile_template_content)
        logger.info(f"ORCHESTRATOR | Profile updated based on LLM inference for user '{user_id}'.")


    if user_message_for_processing and final_ai_response and gcp_project_id and region:
        # Note: If uploaded_file_data is present, gemini_final_model would be GEMINI_VISION_MODEL.
        # This embedding is for text interaction history, so using TEXT_MODEL is appropriate.
        text_for_embedding = f"User: {user_message_for_processing}\nAI: {final_ai_response}"
        embedding_model_for_text = GEMINI_TEXT_MODEL # Usar o modelo de texto para gerar embeddings de texto
        
        # Assegurar que get_embedding usa o modelo de texto para embeddings baseados em texto
        interaction_embedding = await get_embedding(text_for_embedding, gcp_project_id, region, embedding_model_for_text) # Passar o modelo explicitamente
        if interaction_embedding:
            current_utc_timestamp = datetime.now(timezone.utc).isoformat().replace(":", "-").replace(".", "_")
            await add_memory_to_vectorstore(
                user_id=user_id,
                input_text=user_message_for_processing,
                output_text=final_ai_response,
                language=source_language,
                timestamp_for_doc_id=current_utc_timestamp,
                embedding=interaction_embedding
            )
            logger.info(f"ORCHESTRATOR | Interaction embedding for user '{user_id}' submitted for asynchronous saving.")
        else:
            logger.warning(f"ORCHESTRATOR | Could not generate embedding for interaction for user '{user_id}'. Skipping vector memory saving.", exc_info=True)

    emotional_tags = []
    lower_input = user_input_for_saving.lower()

    if intent_detected_in_orchestrator == "tarefa":
        emotional_tags.append("tarefa_criada")
    if intent_detected_in_orchestrator == "projeto":
        emotional_tags.append("projeto_criado")

    if any(w in lower_input for w in ["frustrad", "cansad", "difícil", "procrastin", "adiando", "não consigo", "sobrecarregado"]):
        emotional_tags.append("frustração")
    if any(w in lower_input for w in ["animado", "feliz", "produtivo", "consegui"]):
        emotional_tags.append("positividade")

    psych_profile = user_profile.get('psychological_profile', {})
    if psych_profile.get('diagnoses_and_conditions'):
        for cond in psych_profile['diagnoses_and_conditions']:
            cond_phrase = cond.lower().replace("_", " ")
            if cond_phrase in lower_input or cond_phrase in final_ai_response.lower():
                emotional_tags.append(cond.replace(" ", "_"))

    if psych_profile.get('historical_behavioral_patterns'):
        for pattern in psych_profile['historical_behavioral_patterns']:
            pattern_phrase = pattern.lower().replace("_", " ")
            if pattern_phrase in lower_input or pattern_phrase in final_ai_response.lower():
                emotional_tags.append(pattern.replace(" ", "_"))

    if psych_profile.get('coping_mechanisms'):
        for coping_mechanism in psych_profile['coping_mechanisms']:
            coping_phrase = coping_mechanism.lower().replace("_", " ")
            if coping_phrase in lower_input or coping_phrase in final_ai_response.lower():
                emotional_tags.append(coping_mechanism.replace(" ", "_"))

    if emotional_tags:
        await add_emotional_memory(user_id, user_input_for_saving + " | " + final_ai_response, list(set(emotional_tags)))
        logger.info(f"ORCHESTRATOR | Emotional memory for user '{user_id}' with tags {list(set(emotional_tags))} submitted for asynchronous saving.")

    nudge_message = await analyze_for_nudges(
        user_id, user_message_for_processing, full_history, user_flags_data, # Passar user_flags_data aqui
        user_profile=user_profile
    )
    if nudge_message:
        response_payload["response"] = nudge_message + "\n\n" + response_payload["response"]
        logger.info(f"ORCHESTRATOR | Generated nudge for user '{user_id}': '{nudge_message[:50]}...'.")

    patterns = await get_sabotage_patterns(user_id, 20, user_profile)
    filtered_patterns = {p: f for p, f in patterns.items() if f >= 2}
    if filtered_patterns:
        # Correção da linha de formatação para evitar TypeError
        response_payload["response"] += "\n\n⚠️ **Padrões de auto-sabotagem detectados:**\n" + "\n".join(f"- \"{p}\" ({str(f)} vezes)" for p, f in filtered_patterns.items())
        logger.info(f"ORCHESTRATOR | Detected and added {len(filtered_patterns)} sabotage patterns to response for user '{user_id}'.")

    if mode_debug_on:
        if "orchestrator_debug_log" not in response_payload["debug_info"]:
            response_payload["debug_info"]["orchestrator_debug_log"] = []
        response_payload["debug_info"]["orchestrator_debug_log"].extend(debug_info_logs)
        response_payload["debug_info"]["user_profile_loaded"] = 'true' if user_profile else 'false'
        response_payload["debug_info"]["user_flags_loaded"] = 'true' if user_flags_data else 'false'
        response_payload["debug_info"]["generated_nudge"] = 'true' if nudge_message else 'false'
        response_payload["debug_info"]["system_instruction_snippet"] = final_system_instruction[:500] + "..."


    return response_payload